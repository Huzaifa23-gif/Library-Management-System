**BCSF24M552\_OOP\_PROJECT**

**Library Management System**



**Overview:**

This project is a console-based Library Management System in C++ designed to efficiently manage book records. Users can add, search, update, delete, borrow, and return books, as well as save and load data using binary files. System information is saved in a structured header file.



**Features:**

&nbsp;Add new books

&nbsp;Display all books

&nbsp;Search books by Title, Author, or Genre

&nbsp;Update book information

&nbsp;Delete books

&nbsp;Borrow \& return books

&nbsp;Show available \& borrowed books

&nbsp;Statistics (total books, average price, value, etc.)

&nbsp;Save \& load data from binary file

&nbsp;System information logging



**Menu Options:**

**Option | Function**                

**-------| -----------------------** 

**1      | Add New Book**            

**2      | Display All Books**       

**3      | Search Books**            

**4      | Update Book Information** 

**5      | Delete Book**             

**6      | Borrow Book**             

**7      | Return Book**             

**8      | Display Available Books** 

**9      | Display Borrowed Books**  

**10     | Display Statistics**      

**11     | Save Data to File**       

**12     | Load Data from File**     

**13     | Show System Info**        

**0      | Exit**                    



**File Handling Functions:**

void save\_books\_to\_binary();

void load\_books\_from\_binary();

void save\_system\_header();

void load\_system\_header();



**Memory Management:**

void initialize\_system();

void free\_memory();

void resize\_books\_array();





**Author:**

**Muhammad Huzaifa**

**Roll Number: BCSF24M552**











